package com.example.navigationapp.ui.music;

import androidx.lifecycle.ViewModel;

public class MusicViewModel extends ViewModel {
}
