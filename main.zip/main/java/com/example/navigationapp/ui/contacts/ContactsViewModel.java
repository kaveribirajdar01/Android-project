package com.example.navigationapp.ui.contacts;

import androidx.lifecycle.ViewModel;

public class ContactsViewModel extends ViewModel {

}
